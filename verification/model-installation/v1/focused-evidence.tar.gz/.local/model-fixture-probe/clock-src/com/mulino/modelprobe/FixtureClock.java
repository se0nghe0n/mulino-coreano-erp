package com.mulino.modelprobe;
@org.springframework.context.annotation.Configuration
@org.springframework.context.annotation.Profile("model-fixture-probe")
public class FixtureClock {
 @org.springframework.context.annotation.Bean java.time.Clock modelFixtureExecutionTime(){
  if(!Boolean.getBoolean("model.fixture.disposable"))throw new IllegalStateException("Owned disposable probe only");
  return java.time.Clock.fixed(java.time.Instant.parse(System.getProperty("model.fixture.clock")),java.time.ZoneOffset.UTC);
 }
}
